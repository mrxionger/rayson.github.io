const btn=document.querySelector('button');
const txt=document.querySelector('p');

btn.addEventListener('click',updatebtn);

function updatebtn(){
	if(btn.textContent==='start machine'){
		txt.textContent='the machine is started!';
		btn.textContent='stop machine';
	}else{
		txt.textContent='the machine is stopped!';
		btn.textContent='start machine';
	}

}
