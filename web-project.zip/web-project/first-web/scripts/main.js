//var fso,fldr,s = "";
//fso = new ActiveXObject("Sripting.FileSystemObject");
//fldr = fso.GetBase("/images/")
let myImage = document.querySelector('img');
myImage.onclick = function(){
	let mySrc = myImage.getAttribute('src');
	if(mySrc === 'images/kjy/1.jpg'){
		myImage.setAttribute('src','images/kjy/2.jpg');
	}else{
		myImage.setAttribute('src','images/kjy/1.jpg');
	}
}
